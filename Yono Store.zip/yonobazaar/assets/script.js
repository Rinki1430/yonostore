/* ═══════════════════════════════════════════════════════════ */
/* YONO BAZAAR — SHARED SCRIPT (assets/script.js)              */
/* ═══════════════════════════════════════════════════════════ */

/* ── Utilities ─────────────────────────────────────────────── */

/** Convert a title to a URL slug */
function getSlug(title) {
    return title.toLowerCase().replace(/[^a-z0-9]+/g, '');
}

/** Escape HTML to prevent XSS */
function escapeHTML(str) {
    if (!str) return '';
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
}
/* ── Image Lazy-Load via IntersectionObserver ──────────────── */
/**
 * Attach IntersectionObserver to all [data-src] images in a container.
 * Cards rendered by createCardHTML already use loading="lazy" (native),
 * this observer provides an additional JS fallback and fires a custom
 * event so analytics/tracking can hook in if needed.
 */
function observeLazyImages(container) {
    if (!('IntersectionObserver' in window)) return; // native lazy handles it
    const imgs = container.querySelectorAll('img[loading="lazy"]');
    if (!imgs.length) return;
    const io = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (!entry.isIntersecting) return;
            const img = entry.target;
            if (img.dataset.src) {
                img.src = img.dataset.src;
                delete img.dataset.src;
            }
            observer.unobserve(img);
        });
    }, { rootMargin: '200px' });
    imgs.forEach(img => io.observe(img));
}

/* ── Image Asset Config ────────────────────────────────────── */
/* Central image registry – update paths here to replace images */
const YS_IMAGES = {
    logo:         'https://i.ibb.co/QRP7rh6/website-logo.png',
    ogDefault:    'https://i.ibb.co/QRP7rh6/website-logo.png',
    telegramLogo: 'https://i.ibb.co/QRP7rh6/website-logo.png',
};


/** Detect current page type */
function getPageType() {
    const path = window.location.pathname;
    if (path === '/' || path === '/index.html') return 'home';
    if (path.startsWith('/contact')) return 'contact';
    if (path.startsWith('/disclaimer')) return 'disclaimer';
    if (path.startsWith('/app/')) return 'app';
    return 'home';
}

/* ── Firebase Config ────────────────────────────────────────── */
const firebaseConfig = {
    apiKey: "AIzaSyDJa8igAxQdre8uR5QO14pF3KExLTQuWao",
    authDomain: "download55.firebaseapp.com",
    databaseURL: "https://download55-default-rtdb.firebaseio.com",
    projectId: "download55",
    storageBucket: "download55.firebasestorage.app",
    messagingSenderId: "39783875606",
    appId: "1:39783875606:web:93328003276f26c6a96137",
};

function initFirebase(callback) {
    if (typeof firebase === 'undefined') {
        setTimeout(() => initFirebase(callback), 80);
        return;
    }
    if (!firebase.apps.length) firebase.initializeApp(firebaseConfig);
    const db   = firebase.firestore();
    const rtdb = firebase.database();
    callback(db, rtdb);
}

/* ── Enhanced User Tracking ─────────────────────────────────── */
async function initializeUser(rtdb) {
    try {
        if (typeof FingerprintJS === 'undefined') return;
        const fp = await FingerprintJS.load();
        const result = await fp.get();
        const visitorId = result.visitorId;

        /* Store visitorId for cross-page continuity */
        sessionStorage.setItem('ys_vid', visitorId);

        const statusRef = rtdb.ref('/status/' + visitorId);

        const indianNames = ["Aarav","Vihaan","Aditya","Sai","Aryan","Rohan","Krishna","Ishaan","Ansh","Arjun","Reyansh","Vivaan","Kabir","Shaurya","Dev","Parth","Samarth","Veer","Rudra","Ayaan","Prakash","Suresh","Ramesh","Amit","Sanjay","Rajesh","Vikram","Mohan","Gopal","Anil"];

        function generateDisplayName() {
            return `${indianNames[Math.floor(Math.random() * indianNames.length)]} ${Math.floor(100 + Math.random() * 900)}`;
        }

        /* Collect enhanced device/session metadata */
        function getDeviceMeta() {
            const ua  = navigator.userAgent || '';
            const nav = navigator;
            return {
                screen_res:   `${screen.width}x${screen.height}`,
                language:     nav.language || 'unknown',
                platform:     nav.platform || 'unknown',
                timezone:     Intl.DateTimeFormat().resolvedOptions().timeZone || 'unknown',
                referrer:     document.referrer || 'direct',
                landing_page: window.location.pathname,
                touch:        ('ontouchstart' in window) ? 'yes' : 'no',
                user_agent:   ua.substring(0, 120),
            };
        }

        statusRef.once('value', async (snap) => {
            const existing = snap.val();
            const displayName = existing?.device_name || localStorage.getItem('yonoStoreUserName') || generateDisplayName();
            localStorage.setItem('yonoStoreUserName', displayName);

            const statusData = {
                state:        'online',
                last_changed: firebase.database.ServerValue.TIMESTAMP,
                device_name:  displayName,
                visitor_id:   visitorId,
                page:         window.location.pathname,
                ...getDeviceMeta(),
            };

            rtdb.ref('.info/connected').on('value', (s) => {
                if (!s.val()) return;
                statusRef.onDisconnect().set({
                    ...statusData,
                    state: 'offline',
                }).then(() => statusRef.set(statusData));
            });

            /* Track page visits per user */
            const visitRef = rtdb.ref(`/visits/${visitorId}/${Date.now()}`);
            visitRef.set({
                page: window.location.pathname,
                ts:   firebase.database.ServerValue.TIMESTAMP,
            });

            /* Registration event tracking – fire once per visitor */
            if (!existing) {
                const source   = document.referrer
                    ? (document.referrer.includes('t.me') ? 'telegram'
                        : document.referrer.includes('google') ? 'google'
                        : document.referrer.includes('facebook') || document.referrer.includes('fb.') ? 'facebook'
                        : 'referral')
                    : 'direct';
                const ua       = navigator.userAgent || '';
                const isMobile = /Mobi|Android|iPhone|iPad/i.test(ua);
                const deviceType = isMobile
                    ? (/iPad|Tablet/i.test(ua) ? 'tablet' : 'mobile')
                    : 'desktop';

                rtdb.ref(`/registrations/${visitorId}`).set({
                    ts:          firebase.database.ServerValue.TIMESTAMP,
                    source:      source,
                    device_type: deviceType,
                    landing:     window.location.pathname,
                    referrer:    document.referrer ? document.referrer.substring(0, 200) : 'direct',
                });
            }
        });

    } catch (e) { /* silent */ }
}

/* ── SEO Helpers (shared, used on app pages) ────────────────── */
function updateMetaTag(id, attr, value) {
    const el = document.getElementById(id);
    if (el) el.setAttribute(attr, value);
}

function injectSchema(id, data) {
    let old = document.getElementById(id);
    if (old) old.remove();
    const s  = document.createElement('script');
    s.id     = id;
    s.type   = 'application/ld+json';
    s.text   = JSON.stringify(data);
    document.head.appendChild(s);
}

/* ── Card HTML Builder ──────────────────────────────────────── */
function createCardHTML(app, index, newestAppIds = [], isTopLabel = false) {
    const rank = index + 1;
    let rankClass = 'ranking-number';
    if (rank >= 100) rankClass += ' triple-digit';
    else if (rank >= 10) rankClass += ' double-digit';

    let stickerHtml = '';
    if (isTopLabel || app.isPinned) {
        stickerHtml = '<div class="corner-sticker sticker-top" aria-label="Top app">Top</div>';
    } else if (newestAppIds.includes(app.id)) {
        stickerHtml = '<div class="corner-sticker sticker-new" aria-label="New app">New</div>';
    }

    const titleLen = app.title.length;
    let titleClass = 'app-title';
    if (titleLen > 16) titleClass += ' extra-small-font';
    else if (titleLen > 12) titleClass += ' small-font';

    const appSlug   = getSlug(app.title);
    const safeTitle  = escapeHTML(app.title);
    const safePoster = escapeHTML(app.posterLink);
    const appHref   = `/app/${appSlug}.html`;

    return `
        <article class="app-card" itemscope itemtype="https://schema.org/SoftwareApplication">
            ${stickerHtml}
            <span class="${rankClass}" aria-label="Rank ${rank}">${rank}.</span>
            <a class="app-card-link" href="${appHref}" aria-label="View ${safeTitle}">
                <img src="${safePoster}" alt="${safeTitle} app icon" class="app-poster" loading="lazy" decoding="async" width="60" height="60" itemprop="image">
                <div class="app-details">
                    <h3 class="${titleClass}" itemprop="name">${safeTitle}</h3>
                    <p class="app-info bonus-text"><span aria-hidden="true">🎁</span> Sign Up Bonus ₹100</p>
                    <p class="app-info withdraw-text"><span aria-hidden="true">🏦</span> Min. Withdraw ₹100</p>
                </div>
            </a>
            <a href="${appHref}"
               class="download-btn"
               aria-label="Download ${safeTitle}"
               itemprop="downloadUrl">
                <span class="btn-text">Download</span>
            </a>
        </article>`;
}

/* ── Back To Top ────────────────────────────────────────────── */
function initBackToTop() {
    const btn = document.getElementById('backToTop');
    if (!btn) return;
    window.addEventListener('scroll', () => {
        btn.classList.toggle('show', window.scrollY > 400);
    }, { passive: true });
    btn.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));
}

/* ═══════════════════════════════════════════════════════════ */
/* HOME PAGE LOGIC (index.html)                               */
/* ═══════════════════════════════════════════════════════════ */
function initHomePage(db, rtdb) {
    let allApps       = [];
    let newestAppIds  = [];
    let isCountdownActive = false;
    let hasBannerData     = false;
    let countdownInterval;

    const searchBar     = document.getElementById('searchBar');
    const searchInput   = document.getElementById('searchInput');
    const clearBtn      = document.getElementById('clearSearchBtn');
    const appList       = document.getElementById('appList');
    const countdownCont = document.getElementById('countdownContainer');

    /* Search */
    function openSearch() {
        searchBar.classList.add('visible');
        document.body.classList.add('is-searching');
        searchInput.focus();
        history.pushState({ action: 'search' }, '');
    }
    function closeSearch() {
        if (!searchBar.classList.contains('visible')) return;
        searchBar.classList.remove('visible');
        document.body.classList.remove('is-searching');
        searchInput.value = '';
        clearBtn.classList.remove('visible');
        filterAndRender();
    }

    document.getElementById('searchIcon').addEventListener('click', (e) => {
        e.stopPropagation();
        searchBar.classList.contains('visible') ? history.back() : openSearch();
    });
    document.addEventListener('click', (e) => {
        if (!searchBar.classList.contains('visible')) return;
        if (!searchBar.contains(e.target) && !document.getElementById('searchIcon').contains(e.target)) {
            history.back();
        }
    });
    searchInput.addEventListener('input', (e) => {
        filterAndRender();
        clearBtn.classList.toggle('visible', e.target.value.length > 0);
    });
    clearBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        searchInput.value = '';
        clearBtn.classList.remove('visible');
        filterAndRender();
        searchInput.focus();
    });

    window.addEventListener('popstate', (e) => {
        if (searchBar.classList.contains('visible') && (!e.state || e.state.action !== 'search')) closeSearch();
        if (e.state?.action === 'search') {
            searchBar.classList.add('visible');
            document.body.classList.add('is-searching');
        }
    });

    /* Category Nav */
    document.querySelectorAll('.category-btn').forEach(btn => {
        btn.addEventListener('click', function () {
            document.querySelectorAll('.category-btn').forEach(b => {
                b.classList.remove('active'); b.setAttribute('aria-selected', 'false');
            });
            this.classList.add('active'); this.setAttribute('aria-selected', 'true');
            filterAndRender();
            updateBannersVisibility();
        });
    });

    /* Filter & Render */
    function filterAndRender() {
        const activeCategory = document.querySelector('.category-btn.active')?.dataset.category || 'Yono';
        const searchTerm = searchInput.value.toLowerCase().replace(/\s+/g, '');
        let filtered = activeCategory !== 'Yono'
            ? allApps.filter(a => a.category === activeCategory)
            : allApps;
        if (searchTerm) {
            filtered = filtered.filter(a => a.title.toLowerCase().replace(/\s+/g, '').includes(searchTerm));
        }
        if (filtered.length === 0) {
            appList.innerHTML = '<p id="message">No apps found.</p>';
        } else {
            appList.innerHTML = filtered.map((app, i) => createCardHTML(app, i, newestAppIds)).join('');
            observeLazyImages(appList);  // IO fallback for older browsers
        }
    }

    /* Banner visibility */
    function updateBannersVisibility() {
        const activeCategory = document.querySelector('.category-btn.active')?.dataset.category || 'Yono';
        const homeBanner  = document.getElementById('homeMagicBanner');
        if (activeCategory === 'Rummy') {
            countdownCont.style.display = 'none';
            homeBanner.style.display   = 'none';
        } else {
            if (isCountdownActive) {
                countdownCont.style.display = 'block';
                homeBanner.style.display   = 'none';
            } else {
                countdownCont.style.display = 'none';
                homeBanner.style.display   = hasBannerData ? 'block' : 'none';
            }
        }
    }

    /* Countdown */
    function startCountdown(releaseTimestamp) {
        if (countdownInterval) clearInterval(countdownInterval);
        countdownInterval = setInterval(() => {
            const distance = releaseTimestamp - Date.now();
            if (distance < 0) {
                clearInterval(countdownInterval);
                isCountdownActive = false;
                updateBannersVisibility();
                return;
            }
            const timerEl = document.getElementById('countdownTimer');
            if (timerEl) {
                const pad = n => String(Math.floor(n)).padStart(2, '0');
                timerEl.innerHTML = `
                    <div class="countdown-block"><div class="countdown-number">${pad(distance / 86400000)}</div><div class="countdown-label">Days</div></div>
                    <div class="countdown-block"><div class="countdown-number">${pad((distance % 86400000) / 3600000)}</div><div class="countdown-label">Hours</div></div>
                    <div class="countdown-block"><div class="countdown-number">${pad((distance % 3600000) / 60000)}</div><div class="countdown-label">Mins</div></div>
                    <div class="countdown-block"><div class="countdown-number">${pad((distance % 60000) / 1000)}</div><div class="countdown-label">Secs</div></div>`;
            }
        }, 1000);
    }

    rtdb.ref('countdown').on('value', (snap) => {
        const data = snap.val();
        if (data?.releaseTimestamp && data.releaseTimestamp > Date.now()) {
            isCountdownActive = true;
            countdownCont.innerHTML = `
                <div class="countdown-banner">
                    <img src="${escapeHTML(data.posterLink)}" class="countdown-poster" alt="${escapeHTML(data.title)} countdown" loading="lazy">
                    <div class="countdown-details">
                        <div class="lightning-effect" aria-hidden="true"></div>
                        <div class="countdown-app-title">${escapeHTML(data.title)}</div>
                        <div class="lightning-effect" aria-hidden="true"></div>
                        <div class="countdown-timer-wrapper" id="countdownTimer" aria-live="polite"></div>
                    </div>
                </div>`;
            startCountdown(data.releaseTimestamp);
        } else {
            isCountdownActive = false;
            if (countdownInterval) clearInterval(countdownInterval);
        }
        updateBannersVisibility();
    });

    rtdb.ref('magicBanner').on('value', (snap) => {
        const data = snap.val();
        if (data?.imageUrl) {
            hasBannerData = true;
            document.getElementById('homeMagicImg').src  = data.imageUrl;
            const url = data.targetUrl || '#';
            document.getElementById('homeMagicLink').href = url;
        } else {
            hasBannerData = false;
        }
        updateBannersVisibility();
    });

    db.collection('apps')
      .orderBy('isPinned', 'desc')
      .orderBy('createdAt', 'desc')
      .onSnapshot((snapshot) => {
        allApps = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        newestAppIds = [...allApps]
            .sort((a, b) => (b.createdAt?.seconds || 0) - (a.createdAt?.seconds || 0))
            .slice(0, 2)
            .map(a => a.id);

        filterAndRender();

        document.getElementById('footer-text').style.display          = 'block';
        document.getElementById('telegram-btn-container').style.display = 'block';
        document.getElementById('bottomNavBar').style.display          = 'flex';
    });

    /* Download click animation */
    document.body.addEventListener('click', (e) => {
        const btn = e.target.closest('.download-btn');
        if (btn) {
            btn.classList.add('loading');
            setTimeout(() => btn.classList.remove('loading'), 500);
        }
    });

    initializeUser(rtdb);
    initBackToTop();
}

/* ═══════════════════════════════════════════════════════════ */
/* APP PAGE LOGIC (/app/slug.html)                            */
/* ═══════════════════════════════════════════════════════════ */
function initAppPage(db, rtdb) {
    const origin  = window.location.origin;
    const slug    = window.location.pathname.split('/').pop().replace('.html', '');

    db.collection('apps')
      .orderBy('isPinned', 'desc')
      .orderBy('createdAt', 'desc')
      .get()
      .then((snapshot) => {
        const allApps = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        const app = allApps.find(a => getSlug(a.title) === slug);

        if (!app) {
            document.getElementById('appLoadingArea').innerHTML = '<p style="text-align:center;padding:40px;color:#888;">App not found.</p>';
            return;
        }

        const appUrl      = `${origin}/app/${slug}.html`;
        const ratingVal   = (4.5 + (app.id.charCodeAt(0) % 5) / 10).toFixed(1);
        const ratingCount = 1000 + (app.id.charCodeAt(1) * 17 % 4001);
        const seoDesc     = `Download ${app.title} APK – India's favourite skill-based Yono game. Free ₹100 sign-up bonus, minimum ₹100 withdrawal, 160+ daily games, 24/7 support & instant payouts. Trusted by lakhs of players.`;

        /* SEO */
        document.title = `Download ${app.title} APK - Free ₹100 Bonus | Yono Bazaar`;
        updateMetaTag('meta-description', 'content', seoDesc);
        updateMetaTag('canonical-url', 'href', appUrl);
        updateMetaTag('og-url', 'content', appUrl);
        updateMetaTag('og-title', 'content', `Download ${app.title} APK - Free ₹100 Bonus | Yono Bazaar`);
        updateMetaTag('og-description', 'content', seoDesc);
        updateMetaTag('og-image', 'content', app.posterLink);
        /* Dynamic twitter meta */
        const twTitle = document.querySelector('meta[name="twitter:title"]');
        if (twTitle) twTitle.setAttribute('content', `Download ${app.title} APK - Free ₹100 Bonus | Yono Bazaar`);
        const twDesc = document.querySelector('meta[name="twitter:description"]');
        if (twDesc) twDesc.setAttribute('content', seoDesc);
        const twImg = document.querySelector('meta[name="twitter:image"]');
        if (twImg) twImg.setAttribute('content', app.posterLink);

        injectSchema('seo-schema', {
            "@context": "https://schema.org",
            "@type": "SoftwareApplication",
            "name": app.title,
            "operatingSystem": "Android",
            "applicationCategory": "GameApplication",
            "image": app.posterLink,
            "url": appUrl,
            "description": seoDesc,
            "offers": { "@type": "Offer", "price": "0", "priceCurrency": "INR", "availability": "https://schema.org/InStock" },
            "aggregateRating": {
                "@type": "AggregateRating",
                "ratingValue": ratingVal,
                "ratingCount": ratingCount,
                "bestRating": "5",
                "worstRating": "1"
            }
        });

        injectSchema('breadcrumb-schema', {
            "@context": "https://schema.org",
            "@type": "BreadcrumbList",
            "itemListElement": [
                { "@type": "ListItem", "position": 1, "name": "Home", "item": origin + "/" },
                { "@type": "ListItem", "position": 2, "name": app.title, "item": appUrl }
            ]
        });

        /* Populate DOM */
        document.getElementById('breadcrumbAppName').textContent = app.title;
        document.getElementById('featuredTitle').textContent     = app.title;
        const fi = document.getElementById('featuredImg');
        fi.src = app.posterLink; fi.alt = `${app.title} app icon`;
        document.getElementById('featuredDownloadLink').href     = app.downloadLink;
        document.getElementById('featuredDownloadLink').addEventListener('click', function () {
            const orig = this.innerHTML;
            this.innerHTML = '⏳ Downloading…';
            this.style.opacity = '0.85';
            setTimeout(() => { this.innerHTML = orig; this.style.opacity = '1'; }, 2200);
        });

        /* Feature pills */
        const pillsContainer = document.querySelector('.app-detail-pills');
        if (pillsContainer && app.features && Array.isArray(app.features)) {
            pillsContainer.innerHTML = app.features.map(f =>
                `<span class="app-detail-pill">${escapeHTML(f)}</span>`
            ).join('');
        }

        /* Description – dynamic unique SEO content per app */
        const safeTitle = escapeHTML(app.title);
        (function generateUniqueDescription(title, appId) {
            // Seed-based pseudo-random to ensure same app always gets same variant (no duplicates)
            let seed = 0;
            for (let i = 0; i < appId.length; i++) seed = (seed * 31 + appId.charCodeAt(i)) >>> 0;
            function seededRand(arr) { seed = (seed * 1664525 + 1013904223) >>> 0; return arr[seed % arr.length]; }

            const intros = [
                `<strong>${title}</strong> has quickly become one of the most popular real-money skill games available to Indian players today. Combining fast-paced gameplay with genuine earning potential, this platform offers a refreshing experience for both beginners and seasoned players.`,
                `If you are looking for a trusted real-money gaming platform in India, <strong>${title}</strong> is a name that stands out. Built for players who value fairness, speed, and consistent rewards, it delivers an experience unlike any other.`,
                `<strong>${title}</strong> is redefining the way Indian players engage with online skill-based gaming. Whether you are a first-time player or a competitive enthusiast, this platform has something exciting in store for you.`,
                `Among the growing number of real-money gaming apps in India, <strong>${title}</strong> has carved a niche for itself by offering a seamless, rewarding, and safe environment for players across the country.`,
                `<strong>${title}</strong> brings together the thrill of competitive gaming and the excitement of real rewards on one easy-to-use platform. It is designed specifically for Indian players who demand quality, trust, and instant gratification.`
            ];
            const features = [
                `<ul><li>🎁 <strong>Free ₹100 Welcome Bonus</strong> – Credited instantly upon registration, no conditions attached.</li><li>💸 <strong>Minimum ₹100 Withdrawal</strong> – Start withdrawing your earnings quickly without needing a large balance.</li><li>🎮 <strong>160+ Game Modes</strong> – From classic card games to exciting arcade-style challenges.</li><li>⚡ <strong>Instant Payout Processing</strong> – Winnings are transferred to your bank or UPI within minutes.</li><li>📞 <strong>24/7 Customer Support</strong> – A responsive team is available round the clock to assist you.</li></ul>`,
                `<ul><li>🏆 <strong>Daily Bonus Rewards</strong> – Log in every day to claim free bonus credits and spins.</li><li>🔒 <strong>Verified Secure Platform</strong> – Your data and funds are protected with advanced encryption.</li><li>📱 <strong>Mobile-First Design</strong> – Enjoy smooth gameplay on any Android or iOS device.</li><li>💰 <strong>Low Entry Stakes</strong> – Start playing with as little as ₹10, making it accessible for everyone.</li><li>🎯 <strong>Skill-Based Gameplay</strong> – Your strategy and skill determine the outcome, ensuring fair play.</li></ul>`,
                `<ul><li>✅ <strong>Instant Sign-Up Bonus</strong> – Get ₹100 free on your first registration, no deposit needed.</li><li>🌟 <strong>Leaderboard Competitions</strong> – Compete with top players and win exclusive prizes.</li><li>📲 <strong>Smooth App Experience</strong> – Lightweight and fast, designed for Indian network conditions.</li><li>🏦 <strong>Multiple Payment Options</strong> – UPI, bank transfer, and more for easy deposits and withdrawals.</li><li>🛡️ <strong>Fair Play Guarantee</strong> – All games are monitored to ensure integrity and transparency.</li></ul>`
            ];
            const gameplays = [
                `Getting started on <strong>${title}</strong> is simple and straightforward. Register your account in under a minute using your mobile number. Once registered, your welcome bonus of ₹100 is credited immediately. Choose from over 160 available game modes ranging from classic rummy and card games to fast-paced arcade challenges. Each game mode offers varying prize pools, so you can pick the level that matches your skill and confidence. As you improve, you can participate in daily tournaments and leaderboard events to multiply your earnings significantly.`,
                `Earning on <strong>${title}</strong> is not left to chance. The platform is built on a foundation of skill-based gaming, meaning your decisions, strategies, and consistency directly impact your results. Start with low-stakes rooms if you are new, sharpen your skills, and gradually move to higher-value competitions. Daily check-in rewards ensure that even on quiet days you continue accumulating bonuses. The referral program adds another income stream — invite friends and earn a commission every time they play.`,
                `The earning mechanism on <strong>${title}</strong> is designed to reward active and skilled players. Sign up, claim your free bonus, and jump into any of the available game tables. Each win adds real money to your in-app wallet, which can be withdrawn instantly once you cross the ₹100 threshold. Regular promotional events, seasonal bonuses, and surprise cash drops mean there is always something extra to look forward to.`
            ];
            const trusts = [
                `<strong>${title}</strong> operates with full transparency and player safety as its top priority. The platform uses industry-standard SSL encryption to protect all transactions and personal data. All game outcomes are generated by certified algorithms ensuring fairness across every session. The support team is available 24 hours a day, seven days a week, via live chat and email to resolve any concerns promptly. Thousands of players across India trust this platform for consistent and timely payouts.`,
                `Safety is non-negotiable at <strong>${title}</strong>. From secure login protocols to encrypted payment gateways, every aspect of your experience is protected. The platform complies with applicable regulations and maintains strict responsible gaming guidelines. If you ever have concerns about a transaction or game result, the dedicated support team is always a message away. Your funds are held in secured accounts and processed with complete accuracy.`,
                `What sets <strong>${title}</strong> apart is its unwavering commitment to player trust. The platform has a verified track record of on-time withdrawals, transparent game mechanics, and zero tolerance for fraudulent activity. Player reviews across forums and communities consistently highlight the reliability and responsiveness of the support team. Whether you are depositing your first ₹10 or withdrawing a large win, you can count on a smooth and secure process every time.`
            ];
            const conclusions = [
                `In summary, <strong>${title}</strong> offers Indian players a compelling combination of entertainment, fair competition, and real earning potential. Whether you are drawn to card games, arcade challenges, or tournament play, you will find a home here. The generous welcome bonus, low withdrawal threshold, and instant payouts make it one of the most player-friendly platforms in the market. Join today, claim your ₹100 bonus, and discover what makes <strong>${title}</strong> a standout choice in the Yono Bazaar.`,
                `<strong>${title}</strong> is more than just a gaming app — it is a community of competitive, skilled players united by a love for fair play and real rewards. With its intuitive interface, diverse game library, and consistent payout record, it continues to grow as one of India's most trusted real-money gaming platforms. Start your journey today with a free ₹100 bonus and experience the difference firsthand.`,
                `To conclude, if you are seeking a dependable platform for real-money skill gaming in India, <strong>${title}</strong> checks every box. Generous bonuses, a wide game selection, instant withdrawals, and a secure environment combine to deliver an experience worth coming back to every day. Do not miss out — join <strong>${title}</strong> now through Yono Bazaar and begin your winning journey.`
            ];

            const html = `
                <p>${seededRand(intros)}</p>
                <h3 style="margin:14px 0 8px;font-size:1em;">Key Features</h3>
                ${seededRand(features)}
                <h3 style="margin:14px 0 8px;font-size:1em;">How to Play &amp; Earn</h3>
                <p>${seededRand(gameplays)}</p>
                <h3 style="margin:14px 0 8px;font-size:1em;">Safety &amp; Trust</h3>
                <p>${seededRand(trusts)}</p>
                <h3 style="margin:14px 0 8px;font-size:1em;">Final Thoughts</h3>
                <p>${seededRand(conclusions)}</p>
            `;
            document.getElementById('appDescriptionText').innerHTML = html;
        })(safeTitle, app.id || app.title);
        document.getElementById('seo-hidden-text').innerText = seoDesc;

        /* Popular apps */
        const newestAppIds = [...allApps]
            .sort((a, b) => (b.createdAt?.seconds || 0) - (a.createdAt?.seconds || 0))
            .slice(0, 2).map(a => a.id);
        const randomApps = [...allApps].filter(a => a.id !== app.id).sort(() => 0.5 - Math.random()).slice(0, 15);
        document.getElementById('randomAppList').innerHTML = randomApps.map((a, i) => createCardHTML(a, i, newestAppIds, true)).join('');

        /* Magic Banner */
        rtdb.ref('magicBanner').on('value', (snap) => {
            const data = snap.val();
            const dlBanner = document.getElementById('downloadMagicBanner');
            if (data?.imageUrl) {
                document.getElementById('downloadMagicImg').src  = data.imageUrl;
                document.getElementById('downloadMagicLink').href = data.targetUrl || '#';
                dlBanner.style.display = 'block';
            } else {
                dlBanner.style.display = 'none';
            }
        });

        /* Reveal content */
        document.getElementById('appLoadingArea').style.display = 'none';
        document.getElementById('appContent').style.display     = 'block';
        document.getElementById('bottomNavBar').style.display   = 'flex';
    });

    initializeUser(rtdb);
    initBackToTop();
}

/* ═══════════════════════════════════════════════════════════ */
/* BOOT                                                        */
/* ═══════════════════════════════════════════════════════════ */
document.addEventListener('DOMContentLoaded', () => {
    /* Dynamic WebSite schema — injected on all pages */
    (function () {
        const origin = window.location.origin;
        injectSchema('website-schema', {
            "@context": "https://schema.org",
            "@type": "WebSite",
            "name": "Yono Bazaar",
            "url": origin + "/",
            "description": "India's #1 Yono Rummy App download platform with 160+ games, free bonus and instant withdrawals.",
            "inLanguage": "en-IN",
            "potentialAction": {
                "@type": "SearchAction",
                "target": { "@type": "EntryPoint", "urlTemplate": origin + "/?search={search_term_string}" },
                "query-input": "required name=search_term_string"
            },
            "publisher": {
                "@type": "Organization",
                "name": "Yono Bazaar",
                "url": origin + "/",
                "logo": { "@type": "ImageObject", "url": "https://i.ibb.co/QRP7rh6/website-logo.png", "width": 512, "height": 512 },
                "contactPoint": { "@type": "ContactPoint", "email": "yonoxstores@gmail.com", "contactType": "customer service" },
                "sameAs": ["https://t.me/yono_stores"]
            }
        });
    })();

    const pageType = getPageType();

    initFirebase((db, rtdb) => {
        if (pageType === 'home')  initHomePage(db, rtdb);
        if (pageType === 'app')   initAppPage(db, rtdb);
        if (pageType === 'contact' || pageType === 'disclaimer') {
            initializeUser(rtdb);
            initBackToTop();
            const navBar = document.getElementById('bottomNavBar');
            if (navBar) navBar.style.display = 'flex';
        }
    });
});
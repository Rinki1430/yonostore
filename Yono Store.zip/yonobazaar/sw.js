/* ═══════════════════════════════════════════════════════════ */
/* YONO BAZAAR — SERVICE WORKER (sw.js)                        */
/* Strategy: Cache-First (static) / Network-First (dynamic)   */
/* Bump CACHE_VERSION when deploying new assets               */
/* ═══════════════════════════════════════════════════════════ */

const CACHE_VERSION   = 'ys-v1';
const STATIC_CACHE    = `${CACHE_VERSION}-static`;
const DYNAMIC_CACHE   = `${CACHE_VERSION}-dynamic`;

/* Assets that are immediately pre-cached on SW install */
const STATIC_ASSETS = [
    '/',
    '/index.html',
    '/assets/style.css',
    '/assets/script.js',
    '/contact.html',
    '/disclaimer.html',
    '/offline.html',   /* fallback page */
];

/* ── INSTALL: pre-cache all static assets ─────────────────── */
self.addEventListener('install', (event) => {
    event.waitUntil(
        caches.open(STATIC_CACHE)
            .then(cache => cache.addAll(STATIC_ASSETS))
            .then(() => self.skipWaiting())   /* activate immediately */
    );
});

/* ── ACTIVATE: purge old cache versions ───────────────────── */
self.addEventListener('activate', (event) => {
    event.waitUntil(
        caches.keys().then(keys =>
            Promise.all(
                keys
                    .filter(key => key !== STATIC_CACHE && key !== DYNAMIC_CACHE)
                    .map(key => {
                        console.log('[SW] Deleting old cache:', key);
                        return caches.delete(key);
                    })
            )
        ).then(() => self.clients.claim())    /* take control immediately */
    );
});

/* ── FETCH: routing strategy ──────────────────────────────── */
self.addEventListener('fetch', (event) => {
    const { request } = event;
    const url = new URL(request.url);

    /* Skip non-GET, chrome-extension, and third-party auth requests */
    if (request.method !== 'GET') return;
    if (url.origin !== location.origin &&
        !url.hostname.endsWith('ibb.co') &&
        !url.hostname.endsWith('gstatic.com')) return;

    /* Firebase / Firestore / RTDB — always network-first, no cache */
    if (
        url.hostname.includes('firebaseio.com') ||
        url.hostname.includes('firestore.googleapis.com') ||
        url.hostname.includes('identitytoolkit.googleapis.com')
    ) {
        event.respondWith(networkOnly(request));
        return;
    }

    /* External CDN scripts (Firebase SDK, FingerprintJS, Webpushr) — network-first */
    if (
        url.hostname.includes('gstatic.com') ||
        url.hostname.includes('jsdelivr.net') ||
        url.hostname.includes('webpushr.com')
    ) {
        event.respondWith(networkFirst(request, DYNAMIC_CACHE));
        return;
    }

    /* App images hosted on ibb.co — stale-while-revalidate */
    if (url.hostname.includes('ibb.co')) {
        event.respondWith(staleWhileRevalidate(request, DYNAMIC_CACHE));
        return;
    }

    /* HTML pages — network-first (always serve fresh, fall back to cache) */
    if (request.headers.get('Accept')?.includes('text/html') || url.pathname.endsWith('.html') || url.pathname === '/') {
        event.respondWith(networkFirst(request, STATIC_CACHE, '/offline.html'));
        return;
    }

    /* CSS / JS / fonts / images — cache-first (immutable static assets) */
    event.respondWith(cacheFirst(request, STATIC_CACHE));
});

/* ── Strategies ───────────────────────────────────────────── */

/** Cache-first: serve from cache; fetch + cache if not found */
async function cacheFirst(request, cacheName) {
    const cached = await caches.match(request);
    if (cached) return cached;
    try {
        const response = await fetch(request);
        if (response.ok) {
            const cache = await caches.open(cacheName);
            cache.put(request, response.clone());
        }
        return response;
    } catch {
        return new Response('Offline', { status: 503, statusText: 'Service Unavailable' });
    }
}

/** Network-first: try network; fall back to cache; optionally serve fallback */
async function networkFirst(request, cacheName, fallbackUrl) {
    try {
        const response = await fetch(request);
        if (response.ok) {
            const cache = await caches.open(cacheName);
            cache.put(request, response.clone());
        }
        return response;
    } catch {
        const cached = await caches.match(request);
        if (cached) return cached;
        if (fallbackUrl) {
            const fallback = await caches.match(fallbackUrl);
            if (fallback) return fallback;
        }
        return new Response('You are offline', { status: 503 });
    }
}

/** Network-only: no cache (for Firebase real-time data) */
async function networkOnly(request) {
    try {
        return await fetch(request);
    } catch {
        return new Response('', { status: 503 });
    }
}

/** Stale-while-revalidate: serve cache immediately; refresh in background */
async function staleWhileRevalidate(request, cacheName) {
    const cache  = await caches.open(cacheName);
    const cached = await cache.match(request);

    const fetchPromise = fetch(request).then(response => {
        if (response.ok) cache.put(request, response.clone());
        return response;
    }).catch(() => null);

    return cached || fetchPromise || new Response('', { status: 503 });
}

/**
 * generate-app-pages.js
 * ─────────────────────────────────────────────────────────
 * Run: node generate-app-pages.js
 *
 * Reads all apps from Firebase Firestore and generates a
 * static /app/<slug>.html file for each one using the
 * shared _template.html as the base.
 *
 * Deploy output: the /app/ folder gets committed/uploaded
 * to Netlify alongside index.html, contact.html, disclaimer.html.
 *
 * Usage:
 *   npm install firebase-admin
 *   node generate-app-pages.js
 * ─────────────────────────────────────────────────────────
 */

const fs   = require('fs');
const path = require('path');

// ── Firebase Admin SDK ──────────────────────────────────────
// Place your serviceAccountKey.json in the project root,
// OR set GOOGLE_APPLICATION_CREDENTIALS env var.
const admin = require('firebase-admin');

const serviceAccount = process.env.FIREBASE_SERVICE_ACCOUNT_JSON
    ? JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT_JSON)
    : require('./serviceAccountKey.json');

admin.initializeApp({
    credential: admin.credential.cert(serviceAccount),
    databaseURL: 'https://download55-default-rtdb.firebaseio.com',
});

const db = admin.firestore();

// ── Slug helper ─────────────────────────────────────────────
function getSlug(title) {
    return title.toLowerCase().replace(/[^a-z0-9]+/g, '');
}

function escapeHTML(str) {
    if (!str) return '';
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
}

// ── Template (read once) ────────────────────────────────────
const templatePath = path.join(__dirname, 'app', '_template.html');
const template     = fs.readFileSync(templatePath, 'utf8');
const appDir       = path.join(__dirname, 'app');

// ── Generate pages ──────────────────────────────────────────
async function generatePages() {
    console.log('🔥 Fetching apps from Firestore…');

    const snapshot = await db.collection('apps')
        .orderBy('isPinned', 'desc')
        .orderBy('createdAt', 'desc')
        .get();

    const apps = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    console.log(`📦 Found ${apps.length} apps.`);

    let generated = 0;

    for (const app of apps) {
        const slug    = getSlug(app.title);
        const appUrl  = `https://yonostore.netlify.app/app/${slug}.html`; // Replace with real domain
        const seoDesc = `Download ${app.title} APK – India's favourite skill-based Yono game. Free ₹100 sign-up bonus, minimum ₹100 withdrawal, 160+ daily games, 24/7 support & instant payouts.`;
        const safeTitle = escapeHTML(app.title);

        const html = template
            .replace('<title>Loading App | Yono Bazaar</title>',
                `<title>Download ${safeTitle} APK - Free ₹100 Bonus | Yono Bazaar</title>`)
            .replace('content="Download this Yono App – Free ₹100 bonus, Min ₹100 withdrawal, 160+ games, instant payouts."',
                `content="${escapeHTML(seoDesc)}"`)
            .replace(/<link rel="canonical" id="canonical-url" href="">/,
                `<link rel="canonical" id="canonical-url" href="${appUrl}">`)
            .replace(/content="Yono App \| Yono Bazaar"/g,
                `content="${safeTitle} | Yono Bazaar"`)
            .replace(/content="Download this Yono App – Free ₹100 bonus, Min ₹100 withdrawal, 160\+ games\."/,
                `content="${escapeHTML(seoDesc)}"`)
            .replace(/<meta property="og:url" id="og-url" content="">/,
                `<meta property="og:url" id="og-url" content="${appUrl}">`);

        const outPath = path.join(appDir, `${slug}.html`);
        fs.writeFileSync(outPath, html, 'utf8');
        console.log(`  ✅ /app/${slug}.html`);
        generated++;
    }

    console.log(`\n🎉 Generated ${generated} app pages in /app/`);

    // ── Generate sitemap.xml ─────────────────────────────────
    const DOMAIN = 'https://yonobazaar.com';
    const now    = new Date().toISOString().split('T')[0];
    const staticPages = ['/', '/contact.html', '/disclaimer.html'];

    const slugs = apps.map(a => `/app/${getSlug(a.title)}.html`);
    const allUrls = [...staticPages, ...slugs];

    const urlEntries = allUrls.map(p => `  <url>
    <loc>${DOMAIN}${p}</loc>
    <lastmod>${now}</lastmod>
    <changefreq>${p === '/' ? 'daily' : 'weekly'}</changefreq>
    <priority>${p === '/' ? '1.0' : p.startsWith('/app/') ? '0.8' : '0.5'}</priority>
  </url>`).join('\n');

    const sitemapXml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${urlEntries}
</urlset>`;

    fs.writeFileSync(path.join(__dirname, 'sitemap.xml'), sitemapXml, 'utf8');
    console.log(`🗺️  sitemap.xml generated with ${allUrls.length} URLs.`);

    process.exit(0);
}

generatePages().catch(err => {
    console.error('❌ Error:', err.message);
    process.exit(1);
});
